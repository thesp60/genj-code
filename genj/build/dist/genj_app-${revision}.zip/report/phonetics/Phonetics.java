package phonetics;


/**
 * Our phonetics interface
 */
public interface Phonetics {

    /**
     * encode implementation
     */
    public String encode(String name);

}